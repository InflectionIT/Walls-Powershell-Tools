---
title: Enhancements
keywords: enhancements, features, future
last_updated: December 19, 2018
sidebar: mydoc_sidebar
permalink: mydoc_enhancements.html
folder: mydoc
---

We hope to continue to improve these tools to make them as useful as possible. If you have any suggestions for features or enhancements that you'd like to see, please email us [here](mailto://steve.surrette@inflectionit.com). 