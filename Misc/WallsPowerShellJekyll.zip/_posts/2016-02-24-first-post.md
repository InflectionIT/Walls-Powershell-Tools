---
title:  "Welcome to Jekyll!"
categories: jekyll update
permalink: myupdate.html
tags: [news]
---


Theme updates:

- Permalinks
- Kramdown
- URL specified in config file
- removed PDF output
- removed some of the alternative layouts
- added blog feature
- sidebars configurable per page

{% include links.html %}
